{{/*
Inference API name
*/}}
{{- define "inference-api.name" -}}
{{- printf "%s-api" (include "inference-operator.name" .) }}
{{- end }}

{{/*
Inference API fullname
*/}}
{{- define "inference-api.fullname" -}}
{{- printf "%s-api" (include "inference-operator.fullname" .) }}
{{- end }}

{{/*
Inference API labels
*/}}
{{- define "inference-api.labels" -}}
helm.sh/chart: {{ include "inference-operator.chart" . }}
{{ include "inference-api.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: api
{{- end }}

{{/*
Inference API selector labels
*/}}
{{- define "inference-api.selectorLabels" -}}
app.kubernetes.io/name: {{ include "inference-api.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Inference API service account name
*/}}
{{- define "inference-api.serviceAccountName" -}}
{{- if .Values.api.serviceAccount.create }}
{{- default (include "inference-api.fullname" .) .Values.api.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.api.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Inference API image
*/}}
{{- define "inference-api.image" -}}
{{- $tag := default .Chart.AppVersion .Values.api.image.tag }}
{{- printf "%s:%s" .Values.api.image.repository $tag }}
{{- end }}
