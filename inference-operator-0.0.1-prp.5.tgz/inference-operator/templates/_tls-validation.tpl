{{/*
TLS Prerequisites Validation
Validates that cert-manager and trust-manager are installed before proceeding.
Uses Helm's lookup function to check for CRDs and fail with clear error messages.
*/}}

{{- define "inference-operator.validate-tls-prerequisites" -}}
{{- if .Values.tls.enabled }}
{{- if not .Values.testing.skipValidations -}}

{{/*
Check for cert-manager CRD
*/}}
{{- $certManagerCRD := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "certificates.cert-manager.io" }}
{{- if not $certManagerCRD }}
{{- fail `
================================================================================
                       ERROR: cert-manager NOT FOUND
================================================================================

  cert-manager must be installed before deploying the inference-operator
  with TLS enabled (tls.enabled=true).

--------------------------------------------------------------------------------
  OPTION 1: Install cert-manager
--------------------------------------------------------------------------------

    helm repo add jetstack https://charts.jetstack.io
    helm repo update
    helm install cert-manager jetstack/cert-manager \
      --namespace cert-manager \
      --create-namespace \
      --version v1.16.2 \
      --set crds.enabled=true

--------------------------------------------------------------------------------
  OPTION 2: Disable TLS (not recommended for production)
--------------------------------------------------------------------------------

    helm install inference-operator ./helm/inference-operator \
      --set tls.enabled=false

--------------------------------------------------------------------------------
  For more information: https://cert-manager.io/docs/installation/
================================================================================
` }}
{{- end }}

{{/*
Check for trust-manager CRD
*/}}
{{- $trustManagerCRD := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "bundles.trust.cert-manager.io" }}
{{- if not $trustManagerCRD }}
{{- fail `
================================================================================
                       ERROR: trust-manager NOT FOUND
================================================================================

  trust-manager must be installed before deploying the inference-operator
  with TLS enabled (tls.enabled=true).

  trust-manager is required for automatic CA certificate distribution
  across namespaces, enabling cross-namespace mTLS communication.

--------------------------------------------------------------------------------
  Install trust-manager (after cert-manager):
--------------------------------------------------------------------------------

    helm repo add jetstack https://charts.jetstack.io
    helm repo update
    helm install trust-manager jetstack/trust-manager \
      --namespace cert-manager \
      --version v0.7.1 \
      --set app.trust.namespace=cert-manager

--------------------------------------------------------------------------------
  For more information: https://cert-manager.io/docs/trust/trust-manager/
================================================================================
` }}
{{- end }}

{{- end }}
{{- end }}
{{- end -}}
