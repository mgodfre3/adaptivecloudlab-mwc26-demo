{{/*
Arc-Connected Cluster Validation
Validates that the cluster is connected to Azure Arc before proceeding.
Uses Helm's lookup function to check for CRDs and fail with clear error messages.
*/}}

{{- define "inference-operator.validate-arc-connected" -}}
{{- if not .Values.testing.skipValidations -}}

{{/*
Check for Azure Arc Connected Cluster CRD
*/}}
{{- $arcCRD := lookup "apiextensions.k8s.io/v1" "CustomResourceDefinition" "" "connectedclusters.arc.azure.com" }}
{{- if not $arcCRD }}
{{- fail `
================================================================================
                   ERROR: Arc-Connected Cluster NOT FOUND
================================================================================

  This chart requires deployment on an Azure Arc-connected Kubernetes cluster.
  The connectedclusters.arc.azure.com CRD was not found.

--------------------------------------------------------------------------------
  Connect your cluster to Azure Arc:
--------------------------------------------------------------------------------

    az connectedk8s connect \
      --name <cluster-name> \
      --resource-group <resource-group>

--------------------------------------------------------------------------------
  Prerequisites:
--------------------------------------------------------------------------------

    1. Azure CLI with connectedk8s extension:
       az extension add --name connectedk8s

    2. Sufficient permissions to register the cluster with Azure Arc

    3. Outbound connectivity to Azure endpoints

--------------------------------------------------------------------------------
  Verify Arc connection:
--------------------------------------------------------------------------------

    kubectl get crd connectedclusters.arc.azure.com
    az connectedk8s show --name <cluster-name> --resource-group <resource-group>

--------------------------------------------------------------------------------
  For more information:
  https://learn.microsoft.com/azure/azure-arc/kubernetes/quickstart-connect-cluster
================================================================================
` }}
{{- end }}
{{- end }}

{{- end -}}
