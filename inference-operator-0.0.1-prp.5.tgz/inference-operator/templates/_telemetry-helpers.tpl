{{/*
Telemetry helper templates for OTel Collector integration.

These helpers provide common functionality for telemetry resources
including naming conventions, labels, and endpoint construction.
*/}}

{{/*
Create the OTel Collector service name.
*/}}
{{- define "inference-operator.telemetry.collectorName" -}}
{{- .Values.telemetry.collector.serviceName | default "otel-collector" }}
{{- end }}

{{/*
Create the OTel Collector fully qualified service DNS name.
*/}}
{{- define "inference-operator.telemetry.collectorFQDN" -}}
{{- $name := include "inference-operator.telemetry.collectorName" . -}}
{{- printf "%s.%s.svc.cluster.local" $name .Release.Namespace }}
{{- end }}

{{/*
Create the OTEL_EXPORTER_OTLP_ENDPOINT value based on TLS setting.
FR-013: The endpoint value MUST dynamically use http:// or https:// based on tls.enabled
*/}}
{{- define "inference-operator.telemetry.otlpEndpoint" -}}
{{- $fqdn := include "inference-operator.telemetry.collectorFQDN" . -}}
{{- $port := .Values.telemetry.collector.port | default 4317 -}}
{{- if .Values.tls.enabled -}}
{{- printf "https://%s:%d" $fqdn (int $port) }}
{{- else -}}
{{- printf "http://%s:%d" $fqdn (int $port) }}
{{- end }}
{{- end }}

{{/*
Create the telemetry ConfigMap name.
*/}}
{{- define "inference-operator.telemetry.configMapName" -}}
{{- .Values.telemetry.configMapName | default "foundry-telemetry-config" }}
{{- end }}

{{/*
Create the cluster config ConfigMap name (copied from azure-arc).
*/}}
{{- define "inference-operator.telemetry.clusterConfigName" -}}
{{- .Values.telemetry.init.targetConfigMapName | default "foundry-cluster-config" }}
{{- end }}

{{/*
Create the RBAC ServiceAccount name for the telemetry init job.
*/}}
{{- define "inference-operator.telemetry.serviceAccountName" -}}
{{- .Values.telemetry.rbac.serviceAccountName | default "telemetry-init" }}
{{- end }}

{{/*
Common labels for telemetry resources.
*/}}
{{- define "inference-operator.telemetry.labels" -}}
helm.sh/chart: {{ include "inference-operator.chart" . }}
app.kubernetes.io/name: {{ include "inference-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: telemetry
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels for telemetry collector.
*/}}
{{- define "inference-operator.telemetry.collectorSelectorLabels" -}}
app.kubernetes.io/name: {{ include "inference-operator.telemetry.collectorName" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: telemetry-collector
{{- end }}

{{/*
Common annotations for Helm pre-install/pre-upgrade hooks.
*/}}
{{- define "inference-operator.telemetry.hookAnnotations" -}}
helm.sh/hook: pre-install,pre-upgrade
helm.sh/hook-delete-policy: before-hook-creation
{{- end }}

{{/*
RBAC hook annotations with weight -20 (runs first).
*/}}
{{- define "inference-operator.telemetry.rbacHookAnnotations" -}}
{{ include "inference-operator.telemetry.hookAnnotations" . }}
helm.sh/hook-weight: "-20"
{{- end }}

{{/*
Telemetry init hook annotations with weight -15 (runs after RBAC).
*/}}
{{- define "inference-operator.telemetry.initHookAnnotations" -}}
{{ include "inference-operator.telemetry.hookAnnotations" . }}
helm.sh/hook-weight: "-15"
{{- end }}

{{/*
OTel Collector image with tag.
*/}}
{{- define "inference-operator.telemetry.collectorImage" -}}
{{- $repo := .Values.telemetry.collector.image.repository -}}
{{- $tag := .Values.telemetry.collector.image.tag -}}
{{- printf "%s:%s" $repo $tag }}
{{- end }}

{{/*
Geneva MDM image with tag.
*/}}
{{- define "inference-operator.telemetry.mdmImage" -}}
{{- $repo := .Values.telemetry.geneva.mdm.image.repository -}}
{{- $tag := .Values.telemetry.geneva.mdm.image.tag -}}
{{- printf "%s:%s" $repo $tag }}
{{- end }}

{{/*
Geneva MDSD image with tag.
*/}}
{{- define "inference-operator.telemetry.mdsdImage" -}}
{{- $repo := .Values.telemetry.geneva.mdsd.image.repository -}}
{{- $tag := .Values.telemetry.geneva.mdsd.image.tag -}}
{{- printf "%s:%s" $repo $tag }}
{{- end }}

{{/*
MSI Adapter image with tag.
*/}}
{{- define "inference-operator.telemetry.msiAdapterImage" -}}
{{- $repo := .Values.telemetry.geneva.msiAdapter.image.repository -}}
{{- $tag := .Values.telemetry.geneva.msiAdapter.image.tag -}}
{{- printf "%s:%s" $repo $tag }}
{{- end }}

{{/*
Telemetry init job image with tag.
*/}}
{{- define "inference-operator.telemetry.initImage" -}}
{{- $repo := .Values.telemetry.init.image.repository -}}
{{- $tag := .Values.telemetry.init.image.tag -}}
{{- printf "%s:%s" $repo $tag }}
{{- end }}

{{/*
Server TLS secret name for OTel Collector.
*/}}
{{- define "inference-operator.telemetry.serverTlsSecretName" -}}
otel-collector-server-tls
{{- end }}

{{/*
Client TLS secret name for telemetry emitters.
*/}}
{{- define "inference-operator.telemetry.clientTlsSecretName" -}}
otel-client-tls
{{- end }}

{{/*
DNS SANs for OTel Collector server certificate.
*/}}
{{- define "inference-operator.telemetry.serverDnsSans" -}}
{{- $name := include "inference-operator.telemetry.collectorName" . -}}
- {{ $name }}
- {{ $name }}.{{ .Release.Namespace }}
- {{ $name }}.{{ .Release.Namespace }}.svc
- {{ $name }}.{{ .Release.Namespace }}.svc.cluster.local
{{- end }}
