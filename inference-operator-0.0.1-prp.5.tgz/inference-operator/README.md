# Inference Operator Helm Chart

A Helm chart for deploying the Inference Operator, a Kubernetes operator that manages ML inference workloads.

## Prerequisites

- Kubernetes 1.25+
- Helm 3.0+
- nginx-ingress controller (optional, if using Ingress)

## Installation

### Quick Install

```bash
helm install inference-operator ./helm/inference-operator -n inference-system --create-namespace
```

### Install with Custom Values

```bash
helm install inference-operator ./charts/inference-operator \
  -n inference-system \
  --create-namespace \
  --set image.repository=myregistry.azurecr.io/inference-operator \
  --set operatorConfig.registry=myregistry.azurecr.io
```

### Install from OCI Registry (if published)

```bash
helm install inference-operator oci://myregistry.azurecr.io/helm/inference-operator \
  -n inference-system \
  --create-namespace
```

## Upgrade

```bash
helm upgrade inference-operator ./charts/inference-operator -n inference-system
```

The chart includes a pre-upgrade job that updates the CRD automatically.

## Uninstall

```bash
helm uninstall inference-operator -n inference-system
```

**Note**: By default, the CRD is preserved on uninstall to protect existing InferenceService resources. To delete the CRD manually:

```bash
kubectl delete crd inferenceservices.foundrylocal.azure.com
```

## Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Operator image repository | `inference-operator` |
| `image.tag` | Operator image tag | Chart appVersion |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `replicaCount` | Number of operator replicas | `1` |
| `operatorConfig.registry` | Container registry for inference images | `""` |
| `operatorConfig.cpu.repository` | CPU inference image repository | `foundry-local-cpu` |
| `operatorConfig.cpu.tag` | CPU inference image tag | `latest` |
| `operatorConfig.gpu.repository` | GPU inference image repository | `foundry-local-gpu` |
| `operatorConfig.gpu.tag` | GPU inference image tag | `latest` |
| `crd.install` | Install/update CRD via job | `true` |
| `crd.keep` | Keep CRD on uninstall | `true` |
| `watch.allNamespaces` | Watch all namespaces | `true` |
| `watch.namespace` | Namespace to watch (if not all) | `""` |
| `resources.limits.cpu` | CPU limit | `500m` |
| `resources.limits.memory` | Memory limit | `256Mi` |
| `resources.requests.cpu` | CPU request | `100m` |
| `resources.requests.memory` | Memory request | `128Mi` |

### Telemetry Configuration

The chart includes OpenTelemetry Collector integration for first-party telemetry collection with Geneva (Azure Monitor).

| Parameter | Description | Default |
|-----------|-------------|---------|
| `telemetry.enabled` | Enable telemetry collection | `true` |
| `telemetry.configMapName` | Name of telemetry ConfigMap | `foundry-telemetry-config` |
| `telemetry.collector.image.repository` | OTel Collector image | `otel/opentelemetry-collector-contrib` |
| `telemetry.collector.image.tag` | OTel Collector version | `0.96.0` |
| `telemetry.collector.port` | OTLP gRPC port | `4317` |
| `telemetry.collector.resources.requests.cpu` | Collector CPU request | `200m` |
| `telemetry.collector.resources.requests.memory` | Collector memory request | `256Mi` |
| `telemetry.geneva.mdm.account` | Geneva MDM account | `""` |
| `telemetry.geneva.mdm.namespace` | Geneva MDM namespace | `""` |
| `telemetry.init.source.namespace` | Azure Arc namespace | `azure-arc` |
| `telemetry.init.source.configMapName` | Arc cluster config ConfigMap | `azure-clusterconfig` |

#### Telemetry Architecture

When `telemetry.enabled=true`, the chart deploys:

1. **RBAC Resources** (pre-install hook, weight: -20)
   - ServiceAccount for cross-namespace ConfigMap access
   - Role/RoleBinding in `azure-arc` namespace

2. **Telemetry Init Job** (pre-install hook, weight: -15)
   - Copies `azure-clusterconfig` from `azure-arc` namespace
   - Generates unique `INSTALLATION_ID` (UUID) that persists across upgrades
   - Creates `foundry-cluster-config` with cluster attributes and installation ID

3. **Telemetry Collector Deployment**
   - OTel Collector with OTLP receiver on port 4317
   - Geneva MDM agent for metrics export
   - Geneva MDSD agent for logs export
   - MSI Adapter for Arc Managed Identity tokens

4. **Telemetry ConfigMap**
   - Contains `OTEL_EXPORTER_OTLP_ENDPOINT` for applications
   - TLS certificate paths when `tls.enabled=true`

#### Helm Hook Execution Order

The telemetry components use Helm hooks to ensure proper resource ordering:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         HELM INSTALL / UPGRADE                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  PRE-INSTALL / PRE-UPGRADE HOOKS (ordered by weight)                        │
│  ──────────────────────────────────────────────────                         │
│                                                                             │
│  1. RBAC Resources (weight: -20)                                            │
│     ├── ServiceAccount: foundry-config-reader                               │
│     ├── Role: read-clusterconfig (in azure-arc namespace)                   │
│     └── RoleBinding: foundry-read-clusterconfig                             │
│                                                                             │
│  2. Config Copy Job (weight: -15)                                           │
│     └── Job: copy-cluster-config                                            │
│         ├── Reads azure-clusterconfig from azure-arc namespace              │
│         └── Creates foundry-cluster-config in release namespace             │
│                                                                             │
│  MAIN RESOURCES (no hook)                                                   │
│  ──────────────────────────────────────                                     │
│                                                                             │
│  3. Telemetry Infrastructure                                                │
│     ├── ConfigMap: otel-collector-config                                    │
│     ├── Deployment: telemetry-collector                                     │
│     │   ├── Container: otel-collector                                       │
│     │   ├── Container: mdm                                                  │
│     │   ├── Container: mdsd                                                 │
│     │   └── Container: msi-adapter                                          │
│     └── Service: otel-collector (port 4317)                                 │
│                                                                             │
│  4. Application Resources                                                   │
│     ├── ConfigMap: foundry-telemetry-config                                 │
│     └── Deployment: inference-operator (with envFrom telemetry config)     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Key Points:**
- Hook weight `-20` runs before `-15` (lower weight = earlier execution)
- RBAC must exist before the config copy job can access `azure-arc` namespace
- Config copy must complete before telemetry collector starts (needs cluster config)
- Applications receive `OTEL_EXPORTER_OTLP_ENDPOINT` via the telemetry ConfigMap

#### Disabling Telemetry

To disable telemetry collection:

```bash
helm install inference-operator ./helm/inference-operator \
  --set telemetry.enabled=false
```

#### Requirements for Telemetry

- Cluster must be connected to Azure Arc
- `azure-clusterconfig` ConfigMap must exist in `azure-arc` namespace
- cert-manager required when `tls.enabled=true`

See `values.yaml` for the full list of configurable parameters.

## CRD Management

The chart handles CRD installation and updates through a Kubernetes Job that runs as a Helm pre-install/pre-upgrade hook. This approach:

1. **Initial Install**: Creates the CRD before the operator starts
2. **Upgrades**: Updates the CRD schema for any changes
3. **Uninstall**: Preserves the CRD (configurable via `crd.keep`)

### Manual CRD Management

If you prefer to manage CRDs separately:

```bash
# Disable CRD installation in chart
helm install inference-operator ./charts/inference-operator \
  --set crd.install=false

# Apply CRD manually
kubectl apply -f crd/inferenceservice-crd.yaml
```

## Example Usage

After installation, create an InferenceService:

```yaml
apiVersion: foundrylocal.azure.com/v1
kind: InferenceService
metadata:
  name: my-model
spec:
  name: my-model
  type: cpu
  modelName: qwen2.5-0.5b-instruct
  replicas: 1
  port: 5000
  ingress:
    enabled: true
    path: /models/my-model
    rewritePath: /
```

```bash
kubectl apply -f my-model.yaml
kubectl get isvc
```

### ModelDeployment

Create a ModelDeployment for catalog or custom models:

```yaml
apiVersion: foundrylocal.azure.com/v1
kind: ModelDeployment
metadata:
  name: phi-3-5-mini  # Must be DNS-1035 compliant (see Naming Requirements below)
spec:
  displayName: "Phi-3.5 Mini"
  model:
    catalog:
      name: phi-3-5-mini-instruct-onnx-cpu
      version: "4"
  workloadType: generative
  compute: cpu
  replicas: 1
  endpoint:
    enabled: true
```

```bash
kubectl apply -f phi-3-5-mini.yaml
kubectl get modeldeployments
```

## Naming Requirements

ModelDeployment names must be **DNS-1035 compliant** because they are used to create Kubernetes Service resources. The CRD enforces these rules at creation time:

**Requirements:**
- Only lowercase letters (a-z), numbers (0-9), and hyphens (-)
- Must start with a lowercase letter
- Must end with a lowercase letter or number
- Maximum 63 characters
- **Periods (.) are NOT allowed**

**Valid names:**
- ✅ `phi-3-5-mini`
- ✅ `qwen2-5-coder-7b`
- ✅ `mistral-7b-v0-2`

**Invalid names:**
- ❌ `phi-3.5-mini` (contains period)
- ❌ `Phi-3-5-Mini` (contains uppercase)
- ❌ `3-phi-mini` (starts with number)
- ❌ `phi-mini-` (ends with hyphen)

**Tip:** Use hyphens instead of periods. For example, replace `phi-3.5-mini` with `phi-3-5-mini`. You can preserve the original format in the `spec.displayName` field for human-readable display.
